// datajs.js
// CHỈ định nghĩa initHomeData, KHÔNG chạy ngay khi load file

window.initHomeData = function initHomeData() {
  // Hỗ trợ cả SPA (có #app) lẫn page tĩnh (không có #app)
  const root = document.getElementById("app") || document;

  const IMG = "./imgs/image1.png"; // dùng đường dẫn tương đối (an toàn với Live Server/subfolder)

  const get = (sel) => root.querySelector(sel);

  // (Nếu đang chạy dạng page tĩnh, không cần #reviews để gen data experiences)
  const mustExist = ["#exoticGrid", "#inspGrid", "#expTrack", "#expTrack2"];
  const missingNow = mustExist.filter((sel) => !get(sel));

  if (missingNow.length) {
    // Không return nữa: trang nào có phần nào thì render phần đó.
    // Chỉ retry nhẹ vài lần vì router có thể đang inject HTML.
    const retries = Number(window.__homeInitRetries ?? 0);
    if (retries < 20) {
      window.__homeInitRetries = retries + 1;
      setTimeout(() => window.initHomeData(), 50);
    } else {
      console.warn("initHomeData: missing elements:", missingNow.join(", "));
    }
  } else {
    window.__homeInitRetries = 0;
  }

  // ===== EXOTIC =====
  const exoticData = [
    { title: "Vietnam", img: IMG, href: "#" },
    { title: "Thailand", img: IMG, href: "#" },
    { title: "Cambodia", img: IMG, href: "#" },
    { title: "Laos", img: IMG, href: "#" },
    { title: "Indonesia", img: IMG, href: "#" },
  ];

  const exoticGrid = get("#exoticGrid");
  if (exoticGrid) {
    exoticGrid.innerHTML = exoticData
      .map(
        (item, idx) => `
        <a class="exotic-card${idx === 0 ? " span-2" : ""}" href="${item.href}">
          <img src="${item.img}" alt="${item.title}">
          <span class="exotic-label">${item.title}</span>
        </a>`
      )
      .join("");
  }

  // ===== INSPIRATION =====
  const inspirationData = [
    { title: "Cycling Tours" },
    { title: "Family Trips" },
    { title: "Culinary" },
    { title: "Nature & Wildlife" },
    { title: "Luxury" },
    { title: "Culture" },
    { title: "Beach" },
    { title: "Adventure" },
  ];

  const inspGrid = get("#inspGrid");
  if (inspGrid) {
    inspGrid.innerHTML = inspirationData
      .map((item) => {
        const h = Math.floor(Math.random() * 6) + 8;
        return `
          <a class="insp-card" href="#" style="--h:${h}">
            <div class="card-inner">
              <div class="card-front">
                <img src="${IMG}" alt="${item.title}">
                <span>${item.title}</span>
              </div>
              <div class="card-back">
                <h4>${item.title}</h4>
                <button class="btn-view" type="button">View more</button>
              </div>
            </div>
          </a>`;
      })
      .join("");
  }

  // ===== EXPERIENCES SLIDER 1 (render nhiều card để “hiện hết”) =====
  const exp1 = [
    { title: "A", desc: "AAA", img: IMG },
    { title: "B", desc: "BBB", img: IMG },
    { title: "E", desc: "EEE", img: IMG },
    { title: "F", desc: "FFF", img: IMG },
    { title: "G", desc: "GGG", img: IMG },
    { title: "H", desc: "HHH", img: IMG },
  ];

  const expTrack = get("#expTrack");
  if (expTrack) {
    expTrack.innerHTML = exp1
      .map(
        (item) => `
      <article class="exp-card">
        <div class="exp-img"><img src="${item.img}" alt=""></div>
        <h3 class="exp-h3">${item.title}</h3>
        <p class="exp-p">${item.desc}</p>
      </article>`
      )
      .join("");
  }

  // ===== EXPERIENCES SLIDER 2 (render nhiều card để “hiện hết”) =====
  const exp2 = [
    { title: "C", desc: "CCC", img: IMG },
    { title: "D", desc: "DDD", img: IMG },
    { title: "I", desc: "III", img: IMG },
    { title: "J", desc: "JJJ", img: IMG },
    { title: "K", desc: "KKK", img: IMG },
    { title: "L", desc: "LLL", img: IMG },
  ];

  // tìm trong root trước, nếu không có thì tìm toàn document (để tránh case router chưa inject đúng)
  const expTrack2 = get("#expTrack2") || document.querySelector("#expTrack2");
  if (!expTrack2) {
    console.warn("initHomeData: #expTrack2 not found (root + document)", {
      rootIsApp: root instanceof HTMLElement && root.id === "app",
      hasApp: !!document.getElementById("app"),
      hash: location.hash,
    });
  }

  if (expTrack2) {
    expTrack2.innerHTML = exp2
      .map(
        (item) => `
      <article class="exp-card">
        <div class="exp-img"><img src="${item.img}" alt=""></div>
        <h3 class="exp-h3">${item.title}</h3>
        <p class="exp-p">${item.desc}</p>
      </article>`
      )
      .join("");
  }

  // ===== REVIEWS =====
  const rvStars = get("#rvStars");
  if (rvStars && !rvStars.childElementCount) {
    // để khớp CSS dot của bạn, tạo dot thay vì "★★★★★"
    rvStars.innerHTML = `
        <span class="dot fill"></span>
        <span class="dot fill"></span>
        <span class="dot fill"></span>
        <span class="dot fill"></span>
        <span class="dot fill"></span>
      `;
  }
};

// NOTE: Trong mode router (#app), loadpage.js sẽ gọi initHomeData đúng lúc.
// Nếu bạn mở index.html kiểu page tĩnh không qua router, hãy tự gọi window.initHomeData() từ console.
// (Tắt auto-run để tránh chạy đè/race khi router đang inject HTML)

// Auto-run an toàn:
// - Nếu không có #app (page tĩnh) => chạy luôn.
// - Nếu có #app nhưng đã có các phần tử home trong đó => chạy.
// - Nếu #app đang trống (router sẽ inject) => không chạy để tránh race.
(() => {
  const app = document.getElementById("app");
  if (!app) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => window.initHomeData(), { once: true });
    } else {
      window.initHomeData();
    }
    return;
  }

  const hasHomeInApp = !!app.querySelector("#exoticGrid, #inspGrid, #expTrack, #expTrack2, #reviews");
  if (hasHomeInApp) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => window.initHomeData(), { once: true });
    } else {
      window.initHomeData();
    }
  }
})();
