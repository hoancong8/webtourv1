// Simple hash router: keeps header/footer, swaps only #app content.

(async function () {
  const app = document.getElementById("app");
  if (!app) return;

  const routes = {
    "/home": "./home.html",
    "/about": "./about.html",
  };

  function normalizePath(hash) {
    const h = hash || "#/home";
    const path = h.startsWith("#") ? h.slice(1) : h;
    return routes[path] ? path : "/home";
  }

  function injectHtml(html) {
    // Use DOM parsing for better tolerance than innerHTML for malformed markup.
    const t = document.createElement("template");
    t.innerHTML = html;
    app.replaceChildren(t.content);
  }

  async function loadRoute() {
    const path = normalizePath(location.hash);
    const file = routes[path];

    // cleanup previous page (home page binds many listeners)
    try {
      window.destroyHomeUI?.();
    } catch {
      // ignore
    }

    let html = "";
    try {
      const res = await fetch(file, { cache: "no-store" });
      if (!res.ok) throw new Error(`Failed to load ${file}: ${res.status}`);
      html = await res.text();
    } catch (err) {
      app.innerHTML = `
        <section class="page" style="width:90%;margin:60px auto;">
          <h2 style="color:#2f8f57;">Page load error</h2>
          <p style="color:#6d6d6d;line-height:1.8;">${String(err)}</p>
        </section>`;
      return;
    }

    injectHtml(html);

    if (path === "/home") {
      // init after inject
      requestAnimationFrame(() => {
        window.initHomeData?.();
        window.initHomeUI?.();
      });
    }
  }

  window.addEventListener("hashchange", loadRoute);
  await loadRoute();
})();
